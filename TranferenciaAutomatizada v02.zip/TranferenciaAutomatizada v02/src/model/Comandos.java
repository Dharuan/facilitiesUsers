package model;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Comandos {

	Erros erro;
	
	public void exComand(String userTO, String userFrom, String nameFolder) throws FileNotFoundException{
		
		try{
			
			File file;
			
			//pegando nome do usuario e criando diretorio correspondente
			file = new File("c:\\users\\" + userTO + "\\desktop\\" + nameFolder);
			
			//gravando o arquivo bat no diretorio temporario do usuario
			FileWriter data = new FileWriter("c:\\users\\" + userTO + "\\appData\\Local\\temp\\transfer.bat");
			PrintWriter save = new PrintWriter(data);
			
			//criando comandos dentro do aqruivo bat criado acima
			String comand = "@echo off \n"
							+ " cd\\ \n"
							+ " cd c:\\users\\" + userFrom + "\n"
							+ " xcopy desktop c:\\users\\" + userTO + "\\desktop\\" + nameFolder + " /e" + "\n"
							+ " xcopy documents c:\\users\\" + userTO + "\\desktop\\" + nameFolder + " /e" + "\n"
							+ " xcopy downloads c:\\users\\" + userTO + "\\desktop\\" + nameFolder + " /e" + "\n"
							+ " xcopy favorites c:\\users\\" + userTO + "\\desktop\\" + nameFolder + " /e" + "\n"
							+ " xcopy pictures c:\\users\\" + userTO + "\\desktop\\" + nameFolder + " /e" + "\n"
							+ " exit ";
			
			save.print(comand);
			data.close();
			file.mkdir();
			
			//abrindo e executando cmd
			Runtime.getRuntime().exec("cmd.exe /c start c:\\users\\" + userTO + "\\appData\\Local\\Temp\\transfer.bat");
			
		}catch(Exception e){
			erro.erro1(e);
			//e.printStackTrace();
		}finally{
			
		}
	}
}
