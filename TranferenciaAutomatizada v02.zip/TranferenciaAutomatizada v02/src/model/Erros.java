package model;

public class Erros extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1791149031329025670L;

	public String erro1(Exception ex){
		return "Erro na tranfer�ncia! Contate o suporte! Error: ex0001";
	}
}
