package view;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import model.Comandos;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InteracaoUser extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4124162005024117184L;
	private final JPanel contentPanel = new JPanel();

	/**
	 * Create the dialog.
	 */
	public InteracaoUser() {
		setTitle("Gerar Arquivo");
		setBounds(100, 100, 280, 175);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton btnGerar = new JButton("GERAR");
			btnGerar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					
					String userTO = JOptionPane.showInputDialog(("Digite o nome do seu usu�rio"));
					
					String userFrom = JOptionPane.showInputDialog("Digite o nome do usu�rio que deseja pegar os arquivos");
					
					String nameFolder = JOptionPane.showInputDialog("Digite nome da pasta que seja salvar os aquivos");
					
					Comandos comando = new Comandos();
					
					try {
						
						comando.exComand(userTO, userFrom, nameFolder);
						
						JOptionPane.showMessageDialog(null, "Dados tranferidos com sucesso!");
						
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "Erro na tranfer�ncia! Contate o suporte! Error: x0002");
					}
				}
			});
			btnGerar.setBounds(22, 33, 209, 72);
			contentPanel.add(btnGerar);
		}
	}

}
