package control;

import javax.swing.JDialog;

import view.InteracaoUser;

public class Principal {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			InteracaoUser dialog = new InteracaoUser();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
